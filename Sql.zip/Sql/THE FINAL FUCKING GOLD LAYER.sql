
USE ElectronicsSupplyChainDB;
GO

/*=============================================================================
  GOLD LAYER - FINAL UNIFIED SCRIPT
  Project: End to End Supply Chain Analysis
  Team: Amigos

  PURPOSE
  -------
  1) Create one shared Gold Layer on every team member's device.
  2) Keep the model simple and clear for Power BI.
  3) Keep Header facts separate from Detail facts when the grain is different.
  4) Leave KPI formulas to Power BI.
  5) Exclude Finance (Invoices / Payments) and Sentiment Analysis.

  IMPORTANT DESIGN RULE
  ---------------------
  Gold Views organize clean Silver data for analysis.
  They do NOT calculate final KPI percentages.

  Example:
      Supplier OTD %      -> Power BI
      Production Yield %  -> Power BI
      Fill Rate %         -> Power BI
      Return Rate %       -> Power BI

  Gold only supplies the correct dates, quantities, costs, keys, and statuses.
=============================================================================*/


/*=============================================================================
  0. CREATE GOLD SCHEMA
=============================================================================*/
IF SCHEMA_ID(N'gold') IS NULL
    EXEC(N'CREATE SCHEMA gold AUTHORIZATION dbo;');
GO


/*=============================================================================
  1. DATE DIMENSION
  ---------------------------------------------------------------------------
  Type: Physical table
  Range: Dynamic - calculated automatically from the Silver data.

  Power BI:
  Connect each Fact to gold.DimDate using the main date used in that dashboard.
=============================================================================*/

DROP TABLE IF EXISTS gold.DimDate;
GO

CREATE TABLE gold.DimDate
(
    full_date       DATE        NOT NULL,
    calendar_year   INT         NOT NULL,
    quarter_number  INT         NOT NULL,
    quarter_name    VARCHAR(2)  NOT NULL,
    month_number    INT         NOT NULL,
    month_name      VARCHAR(20) NOT NULL,
    year_month      CHAR(7)     NOT NULL,
    week_number     INT         NOT NULL,
    day_of_month    INT         NOT NULL,
    day_name        VARCHAR(20) NOT NULL,

    CONSTRAINT PK_Gold_DimDate PRIMARY KEY (full_date)
);
GO

DECLARE @MinDate DATE;
DECLARE @MaxDate DATE;

SELECT
    @MinDate = MIN(d),
    @MaxDate = MAX(d)
FROM
(
    SELECT request_date AS d FROM silver.PurchaseRequisitions
    UNION ALL SELECT approval_date FROM silver.PurchaseRequisitions
    UNION ALL SELECT order_date FROM silver.PurchaseOrders
    UNION ALL SELECT expected_delivery_date FROM silver.PurchaseOrders
    UNION ALL SELECT ship_date FROM silver.SupplierShipments
    UNION ALL SELECT expected_arrival_date FROM silver.SupplierShipments
    UNION ALL SELECT actual_arrival_date FROM silver.SupplierShipments
    UNION ALL SELECT receipt_date FROM silver.GoodsReceipts
    UNION ALL SELECT inspection_date FROM silver.QualityInspections
    UNION ALL SELECT CAST(transaction_date AS DATE) FROM silver.RawMaterialInventoryTransactions
    UNION ALL SELECT start_date FROM silver.Production
    UNION ALL SELECT expected_end_date FROM silver.Production
    UNION ALL SELECT actual_end_date FROM silver.Production
    UNION ALL SELECT CAST(transaction_date AS DATE) FROM silver.FinishedGoodsInventoryTransactions
    UNION ALL SELECT order_date FROM silver.SalesOrders
    UNION ALL SELECT shipment_date FROM silver.CustomerShipments
    UNION ALL SELECT expected_delivery_date FROM silver.CustomerShipments
    UNION ALL SELECT actual_delivery_date FROM silver.CustomerShipments
    UNION ALL SELECT return_request_date FROM silver.Returns
    UNION ALL SELECT return_received_date FROM silver.Returns
) D
WHERE d IS NOT NULL;

IF @MinDate IS NULL SET @MinDate = CAST(GETDATE() AS DATE);
IF @MaxDate IS NULL SET @MaxDate = @MinDate;

;WITH DateSeries AS
(
    SELECT @MinDate AS full_date

    UNION ALL

    SELECT DATEADD(DAY, 1, full_date)
    FROM DateSeries
    WHERE full_date < @MaxDate
)
INSERT INTO gold.DimDate
(
    full_date,
    calendar_year,
    quarter_number,
    quarter_name,
    month_number,
    month_name,
    year_month,
    week_number,
    day_of_month,
    day_name
)
SELECT
    full_date,
    YEAR(full_date),
    DATEPART(QUARTER, full_date),
    CONCAT('Q', DATEPART(QUARTER, full_date)),
    MONTH(full_date),
    DATENAME(MONTH, full_date),
    CONVERT(CHAR(7), full_date, 120),
    DATEPART(ISO_WEEK, full_date),
    DAY(full_date),
    DATENAME(WEEKDAY, full_date)
FROM DateSeries
OPTION (MAXRECURSION 0);
GO


/*=============================================================================
  2. SHARED DIMENSIONS
  ---------------------------------------------------------------------------
  These dimensions are created once and reused by all departments.
=============================================================================*/

CREATE OR ALTER VIEW gold.vw_DimDepartment
AS
SELECT
    department_id,
    department_code,
    department_name,
    department_description,
    status
FROM silver.Departments;
GO


CREATE OR ALTER VIEW gold.vw_DimSupplier
AS
SELECT
    supplier_id,
    supplier_code,
    supplier_name,
    supplier_type,
    supplier_category,
    country,
    city,
    status
FROM silver.Suppliers;
GO


CREATE OR ALTER VIEW gold.vw_DimMaterial
AS
SELECT
    material_id,
    material_code,
    material_name,
    material_category,
    material_type,
    uom,
    unit_weight,
    status
FROM silver.Materials;
GO


CREATE OR ALTER VIEW gold.vw_DimProduct
AS
SELECT
    product_id,
    product_code,
    product_name,
    product_category,
    uom,
    standard_cost,
    selling_price,
    status
FROM silver.Products;
GO


CREATE OR ALTER VIEW gold.vw_DimCustomer
AS
SELECT
    customer_id,
    customer_code,
    customer_name,
    customer_type,
    country,
    city,
    registration_date,
    default_discount_percentage,
    status
FROM silver.Customers;
GO


CREATE OR ALTER VIEW gold.vw_DimWarehouse
AS
SELECT
    warehouse_id,
    warehouse_code,
    warehouse_name,
    warehouse_type,
    country,
    city,
    location_description,
    status
FROM silver.Warehouses;
GO


/*=============================================================================
  3. SHARED BRIDGES
=============================================================================*/

/* Grain: one Supplier-Material relationship */
CREATE OR ALTER VIEW gold.vw_BridgeSupplierMaterial
AS
SELECT
    supplier_material_id,
    supplier_id,
    material_id,
    supplier_material_code,
    standard_price,
    lead_time_days,
    minimum_order_quantity,
    preferred_supplier,
    status
FROM silver.SupplierMaterials;
GO


/* Grain: one Product-Material BOM line */
CREATE OR ALTER VIEW gold.vw_BridgeProductBOM
AS
SELECT
    bom_id,
    product_id,
    material_id,
    quantity_required,
    uom,
    status
FROM silver.ProductBOM;
GO


/*=============================================================================
  4. PROCUREMENT & SUPPLIERS
=============================================================================*/

/*-----------------------------------------------------------------------------
  FACT 1: PURCHASE REQUISITION
  Grain: ONE ROW PER PR

  Main use:
  - PR Volume
  - PR Approval Rate
  - PR Approval Lead Time
  - PR -> PO Conversion Rate
  - PR -> PO Cycle Time

  LEFT JOIN is intentional:
  PRs that did NOT become Purchase Orders must remain visible.
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactPurchaseRequisition
AS
SELECT
    pr.pr_id,
    pr.department_id,

    pr.request_date,
    pr.order_date AS pr_order_date,
    pr.required_date,
    pr.approval_date,
    pr.created_date,

    pr.priority,
    pr.approval_status,

    po.po_id,
    po.supplier_id,
    po.order_date AS po_order_date

FROM silver.PurchaseRequisitions pr
LEFT JOIN silver.PurchaseOrders po
    ON po.pr_id = pr.pr_id;
GO


/*-----------------------------------------------------------------------------
  FACT 2: PURCHASE ORDER DETAIL
  Grain: ONE ROW PER PO LINE / MATERIAL

  Main use:
  - Purchase Spend
  - PO Volume using DISTINCTCOUNT(po_id)
  - Average PO Value
  - PPV
  - Purchase analysis by Supplier / Material

  Supplier standard price is brought into the fact so the team can calculate
  PPV easily in Power BI without creating a complex composite-key relationship.
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactPurchaseOrderDetail
AS
SELECT
    pod.po_detail_id,
    pod.po_id,
    pod.pr_detail_id,

    po.pr_id,
    po.supplier_id,
    pr.department_id,
    pod.material_id,

    po.order_date,
    pod.expected_delivery_date,

    po.status AS po_status,
    pod.line_status,

    pod.ordered_quantity,
    pod.unit_price,
    pod.discount_percentage,
    pod.total_amount,

    sm.supplier_material_id,
    sm.standard_price

FROM silver.PurchaseOrderDetails pod

INNER JOIN silver.PurchaseOrders po
    ON po.po_id = pod.po_id

INNER JOIN silver.PurchaseRequisitions pr
    ON pr.pr_id = po.pr_id

OUTER APPLY
(
    SELECT TOP (1)
        x.supplier_material_id,
        x.standard_price
    FROM silver.SupplierMaterials x
    WHERE x.supplier_id = po.supplier_id
      AND x.material_id = pod.material_id
    ORDER BY
        x.preferred_supplier DESC,
        x.supplier_material_id
) sm;
GO


/*-----------------------------------------------------------------------------
  FACT 3: SUPPLIER SHIPMENT - HEADER
  Grain: ONE ROW PER SUPPLIER SHIPMENT

  Main use:
  - Supplier OTD
  - Supplier Delay
  - Transit Time
  - Inbound Shipping Cost
  - Shipping Cost Rate
  - End-to-End Inbound Cycle Time

  IMPORTANT:
  Shipping Cost stays here because it is a Shipment-level value.
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactSupplierShipment
AS
SELECT
    ss.shipment_id,
    ss.po_id,
    ss.supplier_id,

    po.pr_id,
    pr.department_id,

    ss.ship_date,
    ss.expected_arrival_date,
    ss.actual_arrival_date,

    po.order_date AS po_order_date,
    pr.request_date AS pr_request_date,

    ss.total_shipment_value,
    ss.shipping_cost

FROM silver.SupplierShipments ss

INNER JOIN silver.PurchaseOrders po
    ON po.po_id = ss.po_id

INNER JOIN silver.PurchaseRequisitions pr
    ON pr.pr_id = po.pr_id;
GO


/*-----------------------------------------------------------------------------
  FACT 4: SUPPLIER SHIPMENT DETAIL
  Grain: ONE ROW PER MATERIAL LINE IN A SUPPLIER SHIPMENT

  Main use:
  - Ordered vs Received
  - Supplier Shortage
  - Accepted Quantity
  - Rejected Quantity
  - Analysis by Supplier / Material

  Shipping Cost is NOT included here to avoid duplication across lines.
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactSupplierShipmentDetail
AS
SELECT
    ssd.shipment_detail_id,
    ssd.shipment_id,
    ssd.po_detail_id,

    ss.po_id,
    ss.supplier_id,

    pod.pr_detail_id,
    pod.material_id,

    ss.ship_date,
    ss.expected_arrival_date,
    ss.actual_arrival_date,

    pod.ordered_quantity,
    ssd.received_quantity,
    ssd.accepted_quantity,
    ssd.rejected_quantity

FROM silver.SupplierShipmentDetails ssd

INNER JOIN silver.SupplierShipments ss
    ON ss.shipment_id = ssd.shipment_id

INNER JOIN silver.PurchaseOrderDetails pod
    ON pod.po_detail_id = ssd.po_detail_id;
GO


/*=============================================================================
  5. INBOUND QUALITY & RAW MATERIAL INVENTORY
=============================================================================*/

/*-----------------------------------------------------------------------------
  FACT 5: GOODS RECEIPT DETAIL
  Grain: ONE ROW PER RECEIVED MATERIAL LINE

  Main use:
  - Received Quantity
  - Accepted Quantity
  - Rejected Quantity
  - Acceptance Rate
  - Rejection Rate
  - Receipt Processing Time

  Header value total_received_value is intentionally NOT repeated here.
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactGoodsReceiptDetail
AS
SELECT
    grd.gr_detail_id,
    grd.gr_id,
    grd.shipment_detail_id,

    gr.shipment_id,
    ss.supplier_id,
    grd.material_id,

    ss.actual_arrival_date,
    gr.receipt_date,

    grd.batch_number,
    grd.inspection_status,

    grd.received_quantity,
    grd.accepted_quantity,
    grd.rejected_quantity

FROM silver.GoodsReceiptDetails grd

INNER JOIN silver.GoodsReceipts gr
    ON gr.gr_id = grd.gr_id

INNER JOIN silver.SupplierShipments ss
    ON ss.shipment_id = gr.shipment_id;
GO


/*-----------------------------------------------------------------------------
  FACT 6: QUALITY INSPECTION
  Grain: ONE ROW PER QUALITY INSPECTION

  Main use:
  - Defect Rate
  - Reinspection Rate
  - Supplier Quality analysis
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactQualityInspection
AS
SELECT
    qi.inspection_id,
    qi.gr_detail_id,

    grd.gr_id,
    grd.material_id,
    ss.supplier_id,

    qi.inspection_date,

    qi.inspection_type,
    qi.inspection_result,
    qi.defect_reason,
    qi.reinspection_required,
    qi.status,

    qi.inspected_quantity,
    qi.passed_quantity,
    qi.defect_quantity

FROM silver.QualityInspections qi

INNER JOIN silver.GoodsReceiptDetails grd
    ON grd.gr_detail_id = qi.gr_detail_id

INNER JOIN silver.GoodsReceipts gr
    ON gr.gr_id = grd.gr_id

INNER JOIN silver.SupplierShipments ss
    ON ss.shipment_id = gr.shipment_id;
GO


/*-----------------------------------------------------------------------------
  FACT 7: RAW MATERIAL INVENTORY
  Grain: ONE ROW PER MATERIAL-WAREHOUSE CURRENT POSITION

  This is a CURRENT SNAPSHOT, not historical inventory.

  Main use:
  - Quantity On Hand
  - Reserved Quantity
  - Available Quantity
  - Inventory Value
  - Below Reorder Point
  - Critical Stock
  - Out of Stock
  - Overstock
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactRawMaterialInventory
AS
SELECT
    raw_inventory_id,
    warehouse_id,
    material_id,

    quantity_on_hand,
    quantity_reserved,
    reorder_point,
    safety_stock_level,
    max_inventory_level,
    unit_cost,

    last_updated_at

FROM silver.RawMaterialInventory;
GO


/*-----------------------------------------------------------------------------
  FACT 8: RAW MATERIAL INVENTORY TRANSACTION
  Grain: ONE ROW PER RAW MATERIAL INVENTORY TRANSACTION

  Main use:
  - Production Issue Quantity
  - Net Inventory Movement
  - Consumption trends
  - Estimated Days of Supply support

  Transaction types remain exactly as cleaned in Silver.
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactRawInventoryTransaction
AS
SELECT
    tx.raw_transaction_id,
    tx.raw_inventory_id,

    inv.warehouse_id,
    inv.material_id,

    tx.production_id,
    tx.inspection_id,

    tx.transaction_type,
    tx.quantity,
    tx.unit_cost,
    tx.transaction_date,
    tx.reference_code

FROM silver.RawMaterialInventoryTransactions tx

INNER JOIN silver.RawMaterialInventory inv
    ON inv.raw_inventory_id = tx.raw_inventory_id;
GO


/*=============================================================================
  NOTE ABOUT MATERIAL COVERAGE GAP
  ---------------------------------------------------------------------------
  We do NOT create a separate FactMaterialCoverage view in this version.

  Reason:
  RawMaterialInventory is a CURRENT snapshot, while all Production records in
  the current generated dataset are completed historical production orders.

  Comparing today's/current inventory snapshot directly with historical planned
  production would create a misleading "coverage gap".

  The dashboard can still measure:
  - Below Reorder Point
  - Critical Stock
  - Out of Stock
  - Estimated Days of Supply

  If future/open production-plan data is added later, a MaterialCoverage fact
  can be added correctly.
=============================================================================*/


/*=============================================================================
  6. PRODUCTION & FINISHED GOODS
=============================================================================*/

/*-----------------------------------------------------------------------------
  FACT 9: PRODUCTION ORDER
  Grain: ONE ROW PER PRODUCTION ORDER

  Main use:
  - Production Attainment
  - Production Variance
  - Completion Rate
  - Production OTD
  - Production Delay
  - Production Yield
  - Production Reject Rate
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactProductionOrder
AS
SELECT
    production_id,
    product_id,

    start_date,
    expected_end_date,
    actual_end_date,

    production_status,

    planned_quantity,
    production_quantity,
    rejected_quantity

FROM silver.Production;
GO


/*-----------------------------------------------------------------------------
  FACT 10: PRODUCTION MATERIAL
  Grain: ONE ROW PER MATERIAL USED IN A PRODUCTION ORDER

  Main use:
  - Planned / Expected Material Consumption
  - Actual Material Consumption
  - Material Usage Variance
  - Material Consumption per Unit
  - Scrap Quantity
  - Scrap Rate
  - Scrap Cost
  - Material Cost analysis

  IMPORTANT:
  planned_quantity / production_quantity / rejected_quantity repeat for every
  material line of the same production order.
  Use FactProductionOrder for total production KPIs.
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactProductionMaterial
AS
SELECT
    pd.production_detail_id,
    pd.production_id,
    pd.bom_id,
    pd.raw_inventory_id,

    p.product_id,
    bom.material_id,
    inv.warehouse_id,

    p.start_date,
    p.expected_end_date,
    p.actual_end_date,
    p.production_status,

    bom.quantity_required,

    p.planned_quantity,
    p.production_quantity,
    p.rejected_quantity,

    pd.actual_consumed_quantity,
    pd.return_quantity,
    pd.scrap_quantity,

    pd.unit_cost,
    pd.total_material_cost

FROM silver.ProductionDetails pd

INNER JOIN silver.Production p
    ON p.production_id = pd.production_id

INNER JOIN silver.ProductBOM bom
    ON bom.bom_id = pd.bom_id

INNER JOIN silver.RawMaterialInventory inv
    ON inv.raw_inventory_id = pd.raw_inventory_id;
GO


/*-----------------------------------------------------------------------------
  FACT 11: FINISHED GOODS INVENTORY
  Grain: ONE ROW PER PRODUCT-WAREHOUSE CURRENT POSITION

  Main use:
  - FG On Hand
  - FG Reserved Quantity
  - FG Available Quantity
  - Low Stock
  - FG Standard Inventory Value

  This is a CURRENT SNAPSHOT.
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactFinishedGoodsInventory
AS
SELECT
    fg.finished_goods_inventory_id,
    fg.warehouse_id,
    fg.product_id,

    fg.quantity_on_hand,
    fg.quantity_reserved,
    fg.reorder_point,
    fg.safety_stock_level,

    p.standard_cost,

    fg.last_updated_at

FROM silver.FinishedGoodsInventory fg

INNER JOIN silver.Products p
    ON p.product_id = fg.product_id;
GO


/*-----------------------------------------------------------------------------
  FACT 12: FINISHED GOODS INVENTORY TRANSACTION
  Grain: ONE ROW PER FG INVENTORY TRANSACTION

  Main use:
  - Finished Goods Inflow
  - Finished Goods Outflow
  - Net Movement
  - Inventory movement trend
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactFinishedGoodsTransaction
AS
SELECT
    tx.finished_inventory_transaction_id,
    tx.finished_goods_inventory_id,

    inv.warehouse_id,
    inv.product_id,

    tx.production_id,
    tx.customer_shipment_detail_id,

    tx.transaction_type,
    tx.quantity,
    tx.unit_cost,
    tx.transaction_date,
    tx.reference_code

FROM silver.FinishedGoodsInventoryTransactions tx

INNER JOIN silver.FinishedGoodsInventory inv
    ON inv.finished_goods_inventory_id = tx.finished_goods_inventory_id;
GO


/*=============================================================================
  7. SALES, DELIVERY & RETURNS
=============================================================================*/

/*-----------------------------------------------------------------------------
  FACT 13: SALES ORDER DETAIL
  Grain: ONE ROW PER PRODUCT LINE IN A SALES ORDER

  Main use:
  - Total Orders using DISTINCTCOUNT(sales_order_id)
  - Total Ordered Quantity
  - Ordered Sales Value
  - Average Order Value
  - Sales by Customer / Product

  Product price and standard cost are included at line grain for easy Power BI
  calculations.
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactSalesOrderDetail
AS
SELECT
    sod.sales_order_detail_id,
    sod.sales_order_id,

    so.customer_id,
    sod.product_id,

    so.order_date,
    so.required_delivery_date,

    so.sales_order_status,
    sod.line_status,

    so.payment_method,
    so.tax_percentage,

    sod.ordered_quantity,

    p.selling_price,
    p.standard_cost

FROM silver.SalesOrderDetails sod

INNER JOIN silver.SalesOrders so
    ON so.sales_order_id = sod.sales_order_id

INNER JOIN silver.Products p
    ON p.product_id = sod.product_id;
GO


/*-----------------------------------------------------------------------------
  FACT 14: CUSTOMER SHIPMENT - HEADER
  Grain: ONE ROW PER CUSTOMER SHIPMENT

  Main use:
  - Customer OTD
  - Average Delivery Delay
  - Delivery Lead Time
  - Outbound Shipping Cost

  IMPORTANT:
  Shipping Cost remains here because it is shipment-level.
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactCustomerShipment
AS
SELECT
    cs.customer_shipment_id,
    cs.sales_order_id,

    so.customer_id,
    cs.warehouse_id,

    so.order_date,
    so.required_delivery_date,

    cs.shipment_date,
    cs.expected_delivery_date,
    cs.actual_delivery_date,

    cs.shipping_method,
    cs.shipping_cost,
    cs.shipment_status,
    cs.delivery_confirmation

FROM silver.CustomerShipments cs

INNER JOIN silver.SalesOrders so
    ON so.sales_order_id = cs.sales_order_id;
GO


/*-----------------------------------------------------------------------------
  FACT 15: CUSTOMER SHIPMENT DETAIL
  Grain: ONE PRODUCT LINE IN A CUSTOMER SHIPMENT

  Main use:
  - Quantity Fill Rate
  - Unfulfilled Quantity
  - Partial Fulfillment
  - Fulfilled / Shipped Sales Value
  - Standard COGS
  - Estimated Gross Profit

  Shipping Cost is NOT included here to avoid duplication across product lines.
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactCustomerShipmentDetail
AS
SELECT
    csd.customer_shipment_detail_id,
    csd.customer_shipment_id,
    csd.sales_order_detail_id,

    cs.sales_order_id,
    so.customer_id,
    sod.product_id,
    cs.warehouse_id,

    so.order_date,
    cs.shipment_date,
    cs.expected_delivery_date,
    cs.actual_delivery_date,

    so.sales_order_status,
    sod.line_status,
    cs.shipment_status,

    sod.ordered_quantity,
    csd.shipped_quantity,

    p.selling_price,
    p.standard_cost

FROM silver.CustomerShipmentDetails csd

INNER JOIN silver.CustomerShipments cs
    ON cs.customer_shipment_id = csd.customer_shipment_id

INNER JOIN silver.SalesOrders so
    ON so.sales_order_id = cs.sales_order_id

INNER JOIN silver.SalesOrderDetails sod
    ON sod.sales_order_detail_id = csd.sales_order_detail_id

INNER JOIN silver.Products p
    ON p.product_id = sod.product_id;
GO


/*-----------------------------------------------------------------------------
  FACT 16: RETURN
  Grain: ONE RETURN RECORD

  Main use:
  - Return Rate
  - Returned Quantity
  - Return Processing Time
  - Top Return Reasons
  - Return analysis by Product / Customer / Warehouse
-----------------------------------------------------------------------------*/
CREATE OR ALTER VIEW gold.vw_FactReturn
AS
SELECT
    r.return_id,
    r.customer_shipment_detail_id,

    csd.customer_shipment_id,
    sod.sales_order_detail_id,
    cs.sales_order_id,

    so.customer_id,
    sod.product_id,
    cs.warehouse_id,

    cs.shipment_date,
    cs.actual_delivery_date,

    r.return_request_date,
    r.return_received_date,

    r.returned_quantity,
    csd.shipped_quantity,

    r.return_reason,
    r.product_condition,
    r.return_status

FROM silver.Returns r

INNER JOIN silver.CustomerShipmentDetails csd
    ON csd.customer_shipment_detail_id = r.customer_shipment_detail_id

INNER JOIN silver.CustomerShipments cs
    ON cs.customer_shipment_id = csd.customer_shipment_id

INNER JOIN silver.SalesOrderDetails sod
    ON sod.sales_order_detail_id = csd.sales_order_detail_id

INNER JOIN silver.SalesOrders so
    ON so.sales_order_id = cs.sales_order_id;
GO


/*=============================================================================
  8. FINAL OBJECT LIST
  ---------------------------------------------------------------------------
  1  gold.DimDate

  Dimensions:
  2  vw_DimDepartment
  3  vw_DimSupplier
  4  vw_DimMaterial
  5  vw_DimProduct
  6  vw_DimCustomer
  7  vw_DimWarehouse

  Bridges:
  8  vw_BridgeSupplierMaterial
  9  vw_BridgeProductBOM

  Procurement:
  10 vw_FactPurchaseRequisition
  11 vw_FactPurchaseOrderDetail
  12 vw_FactSupplierShipment
  13 vw_FactSupplierShipmentDetail

  Inbound / RM:
  14 vw_FactGoodsReceiptDetail
  15 vw_FactQualityInspection
  16 vw_FactRawMaterialInventory
  17 vw_FactRawInventoryTransaction

  Production / FG:
  18 vw_FactProductionOrder
  19 vw_FactProductionMaterial
  20 vw_FactFinishedGoodsInventory
  21 vw_FactFinishedGoodsTransaction

  Sales / Delivery / Returns:
  22 vw_FactSalesOrderDetail
  23 vw_FactCustomerShipment
  24 vw_FactCustomerShipmentDetail
  25 vw_FactReturn

  Total Gold Objects = 25
=============================================================================*/


/*=============================================================================
  9. SIMPLE QA CHECKS
  These SELECT statements do not create extra views.
=============================================================================*/

PRINT '============================================================';
PRINT 'GOLD LAYER CREATED';
PRINT '============================================================';


/* Check Gold object count */
SELECT
    COUNT(*) AS gold_objects
FROM
(
    SELECT t.name
    FROM sys.tables t
    INNER JOIN sys.schemas s
        ON s.schema_id = t.schema_id
    WHERE s.name = 'gold'

    UNION ALL

    SELECT v.name
    FROM sys.views v
    INNER JOIN sys.schemas s
        ON s.schema_id = v.schema_id
    WHERE s.name = 'gold'
) x;
GO


/* Fact row counts */
SELECT 'vw_FactPurchaseRequisition' AS fact_name, COUNT(*) AS rows_count
FROM gold.vw_FactPurchaseRequisition

UNION ALL
SELECT 'vw_FactPurchaseOrderDetail', COUNT(*)
FROM gold.vw_FactPurchaseOrderDetail

UNION ALL
SELECT 'vw_FactSupplierShipment', COUNT(*)
FROM gold.vw_FactSupplierShipment

UNION ALL
SELECT 'vw_FactSupplierShipmentDetail', COUNT(*)
FROM gold.vw_FactSupplierShipmentDetail

UNION ALL
SELECT 'vw_FactGoodsReceiptDetail', COUNT(*)
FROM gold.vw_FactGoodsReceiptDetail

UNION ALL
SELECT 'vw_FactQualityInspection', COUNT(*)
FROM gold.vw_FactQualityInspection

UNION ALL
SELECT 'vw_FactRawMaterialInventory', COUNT(*)
FROM gold.vw_FactRawMaterialInventory

UNION ALL
SELECT 'vw_FactRawInventoryTransaction', COUNT(*)
FROM gold.vw_FactRawInventoryTransaction

UNION ALL
SELECT 'vw_FactProductionOrder', COUNT(*)
FROM gold.vw_FactProductionOrder

UNION ALL
SELECT 'vw_FactProductionMaterial', COUNT(*)
FROM gold.vw_FactProductionMaterial

UNION ALL
SELECT 'vw_FactFinishedGoodsInventory', COUNT(*)
FROM gold.vw_FactFinishedGoodsInventory

UNION ALL
SELECT 'vw_FactFinishedGoodsTransaction', COUNT(*)
FROM gold.vw_FactFinishedGoodsTransaction

UNION ALL
SELECT 'vw_FactSalesOrderDetail', COUNT(*)
FROM gold.vw_FactSalesOrderDetail

UNION ALL
SELECT 'vw_FactCustomerShipment', COUNT(*)
FROM gold.vw_FactCustomerShipment

UNION ALL
SELECT 'vw_FactCustomerShipmentDetail', COUNT(*)
FROM gold.vw_FactCustomerShipmentDetail

UNION ALL
SELECT 'vw_FactReturn', COUNT(*)
FROM gold.vw_FactReturn;
GO


/* Duplicate grain checks - every result below should return ZERO rows */

-- PR grain
SELECT pr_id, COUNT(*) AS duplicate_count
FROM gold.vw_FactPurchaseRequisition
GROUP BY pr_id
HAVING COUNT(*) > 1;

-- PO Detail grain
SELECT po_detail_id, COUNT(*) AS duplicate_count
FROM gold.vw_FactPurchaseOrderDetail
GROUP BY po_detail_id
HAVING COUNT(*) > 1;

-- Supplier Shipment grain
SELECT shipment_id, COUNT(*) AS duplicate_count
FROM gold.vw_FactSupplierShipment
GROUP BY shipment_id
HAVING COUNT(*) > 1;

-- Supplier Shipment Detail grain
SELECT shipment_detail_id, COUNT(*) AS duplicate_count
FROM gold.vw_FactSupplierShipmentDetail
GROUP BY shipment_detail_id
HAVING COUNT(*) > 1;

-- Sales Order Detail grain
SELECT sales_order_detail_id, COUNT(*) AS duplicate_count
FROM gold.vw_FactSalesOrderDetail
GROUP BY sales_order_detail_id
HAVING COUNT(*) > 1;

-- Customer Shipment grain
SELECT customer_shipment_id, COUNT(*) AS duplicate_count
FROM gold.vw_FactCustomerShipment
GROUP BY customer_shipment_id
HAVING COUNT(*) > 1;

-- Customer Shipment Detail grain
SELECT customer_shipment_detail_id, COUNT(*) AS duplicate_count
FROM gold.vw_FactCustomerShipmentDetail
GROUP BY customer_shipment_detail_id
HAVING COUNT(*) > 1;

-- Return grain
SELECT return_id, COUNT(*) AS duplicate_count
FROM gold.vw_FactReturn
GROUP BY return_id
HAVING COUNT(*) > 1;
GO


/* Basic reconciliation checks */

-- Shipped quantity should not exceed ordered quantity.
SELECT *
FROM gold.vw_FactCustomerShipmentDetail
WHERE shipped_quantity > ordered_quantity;

-- Returned quantity should not exceed shipped quantity.
SELECT *
FROM gold.vw_FactReturn
WHERE returned_quantity > shipped_quantity;

-- Accepted + Rejected should not exceed Received.
SELECT *
FROM gold.vw_FactGoodsReceiptDetail
WHERE accepted_quantity + rejected_quantity > received_quantity;
GO


PRINT 'Gold Layer build and QA checks completed.';
GO
